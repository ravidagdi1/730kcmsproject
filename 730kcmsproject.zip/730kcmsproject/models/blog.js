const mongoose=require('mongoose')


const blogschema=mongoose.Schema({
    title:{
        type:String,
        required:true
    },
    desc:{
        type:String,
        required:true
    },
    img:{
        type:String,

    },
    postedDate:{
        type:Date,
        required:true,
        default:new Date()
    },
    user:{
        type:String,
        required:true
    }
})

module.exports=mongoose.model('blog',blogschema)