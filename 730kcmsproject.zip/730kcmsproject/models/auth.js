const mongoose=require('mongoose')


const authSchema=mongoose.Schema({
    firstName:{
        type:String,
        required:true
    },
    lastName:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type:String,
        required:true
    },
    mobile:{
        type:Number,
        required:true
    },
    gender:{
        type:String,
        required:true
    },
    createDate:{
        type:Date,
        default:new Date().toString(),
        required:true
    },
    status:{
        type:String,
        required:true,
        default:'Suspended'
    },
    sub:{
        type:String,
        default:'free',
        required:true
    }
})

module.exports=mongoose.model('auth',authSchema)