const blogtable=require('../models/blog')


exports.addform=(req,res)=>{
    const username=req.session.username
    res.render('users/addblog.ejs',{username})
}

exports.addblog=async(req,res)=>{

    const{title,desc}=req.body
    const username=req.session.username
    if(req.file){
    const filename=req.file.filename
    var newdata=new blogtable({title:title,desc:desc,img:filename,user:username})
    }else{
        var newdata=new blogtable({title:title,desc:desc,img:'twitter.png',user:username})

    }
    newdata.save()
    //console.log(newdata)
    res.redirect('/users/myblog/Succssfully Blog Added')
    
}


exports.myblog=async(req,res)=>{
    const message=req.params.mess
    const username=req.session.username
    const data=await blogtable.find({user:username})
    res.render('users/myblog.ejs',{username,message,data})
}


exports.allblog=async(req,res)=>{
    const username1=req.session.username
    const b=username1.split('@')
    const username=b[0]
    const data=await blogtable.find().sort({postedDate:-1})
    res.render('users/allbolgs.ejs',{username,data})
}