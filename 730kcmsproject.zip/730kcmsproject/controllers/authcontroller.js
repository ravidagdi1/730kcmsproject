const authTable=require('../models/auth')
const nodemailer=require('nodemailer')
const bcrypt=require('bcrypt')


exports.login=(req,res)=>{
    res.render('auth/login.ejs',{message:''})
}

exports.singup=(req,res)=>{
    res.render('auth/singup.ejs',{mess:''})
}

exports.createuser=async(req,res)=>{
let mess=null
const{fname,lname,email,pass,mob,gender}=req.body
const convertedpass=await bcrypt.hash(pass,10)
const emailcheck=await authTable.findOne({email:email})
if(emailcheck==null){
const newuser=new authTable({firstName:fname,lastName:lname,email:email,password:convertedpass,mobile:mob,gender:gender})
newuser.save()
//console.log(newuser)
const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    auth: {
      // TODO: replace `user` and `pass` values from <https://forwardemail.net>
      user:'rtestexpress@gmail.com',
      pass:'cbfhvatynadixfuv',
    },
  });
transporter.sendMail({
    from:'rtestexpress@gmail.com',
    to:email,
    subject:'Email Activation Link',
    html:`<a href=http://localhost:5000/verifylink/${newuser.id}>Click to active</a>`,
})
mess='Account Created Successfully.Email Verifaction LInk has been sent to Regsiterted Email Id!!'
}else{
mess='Email is already registerted with us!!'
}
res.render('auth/singup.ejs',{mess})
    }

exports.statusupdate=async(req,res)=>{
    const id=req.params.id
   await authTable.findByIdAndUpdate(id,{status:'Active'})
   res.render('auth/message.ejs')
}


exports.emailform=(req,res)=>{
    res.render('auth/forgotform.ejs',{mess:''})
    }
exports.forgotlinksend=async(req,res)=>{
    let mess=null
    const{email}=req.body
   const emailcheck= await authTable.findOne({email:email})
   if(emailcheck!=null){
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
          // TODO: replace `user` and `pass` values from <https://forwardemail.net>
          user:'rtestexpress@gmail.com',
          pass:'cbfhvatynadixfuv',
        },
      });
      transporter.sendMail({
        from:'rtestexpress@gmail.com',
        to:email,
        subject:'Forgot Password Link',
        html:`<a href=http://localhost:5000/forgotnewpass/${emailcheck.id}>Click to get New Password</a>`,
    })
    mess='Link has been sent to your Registerted Email Id!!'
   }else{
    mess='Email not regsiterted with us!!!'
   }
   res.render('auth/forgotform.ejs',{mess})
}

exports.forgotnewform=(req,res)=>{
    res.render('auth/forgotnewpass.ejs',{message:''})
}

exports.forgotpasswordupdate=async(req,res)=>{
    let message=null
    const{npass,cpass}=req.body
    if(npass==cpass){
        const convertednpass= await bcrypt.hash(npass,10)
    await authTable.findByIdAndUpdate(req.params.id,{password:convertednpass})
    //message='New Password has been created!Please login Again'
    res.render('auth/forgotmessage.ejs')
    }else{
        //res.send('password not matched!!!')
        message='password not matched!!!'
        res.render('auth/forgotnewpass.ejs',{message})
    }
   
     
}


exports.logincheck=async(req,res)=>{
    const{us,pass}=req.body
    let message=null
    const usercheck=await authTable.findOne({email:us})
    if(usercheck!=null){
        const passwordcompare=await bcrypt.compare(pass,usercheck.password)
        if(passwordcompare){
            if(usercheck.status=='Active'){
                req.session.Auth=true
                req.session.username=us
                req.session.sub=usercheck.sub
            res.redirect('/users/allblogs')
            }else{
                message='Your account is not verfied!Please check email for verfiy link'
                res.render('auth/login.ejs',{message})
            }

        }else{
            message:'Wrong Password!!'
            res.render('auth/login.ejs',{message})
        }
    }else{
        message='Wrong Email'
        res.render('auth/login.ejs',{message})
    }
    
}

exports.changepasswordform=(req,res)=>{
    const username=req.session.username
    res.render('auth/changepassword.ejs',{username,message:''})
}

exports.changepassword=async(req,res)=>{
    const{cpass,npass,copass}=req.body
    const username=req.session.username
    const currentuserdata=await authTable.findOne({email:username})
    //console.log(currentuserdata)
    const newpassword=await bcrypt.hash(npass,10)
    const comparepass=await bcrypt.compare(cpass,currentuserdata.password)
    if(comparepass){
        if(npass==copass){
            await authTable.findByIdAndUpdate(currentuserdata.id,{password:newpassword})
            req.session.destroy()
            res.render('auth/changepassmess.ejs')
            //res.send("password has been changed")
        }else{
            //res.send("password Not matched")
            res.render('auth/changepassword.ejs',{username,message:'password Not matched'})

        }

    }else{
        //res.send("Cuurent Password Not matched")
        res.render('auth/changepassword.ejs',{username,message:'Curent Password Not matched'})

    }

}

exports.profileform=async(req,res)=>{
    const message=req.params.mess
    const username=req.session.username
    const data=await authTable.findOne({email:username})
    res.render('auth/myprofileform.ejs',{username,data,message})
}

exports.profileupdate=async(req,res)=>{
    const id=req.params.id
    const{fname,lname,mobile}=req.body
    await authTable.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mobile})
    res.redirect('/myprofile/Successfuly Profile Has been Updated')


}