const express=require("express")//function
const app=express()//module
app.use(express.urlencoded({extended:false}))
const userRouter=require('./routers/userrouter')
const adminRouter=require('./routers/userrouter')
const authRouter=require('./routers/auth')
const mongoose=require('mongoose')
const session=require('express-session')
mongoose.connect('mongodb://127.0.0.1:27017/730kcmsproject').then(()=>{console.log("connected to DB!!")}).catch((error)=>{console.log(error.message)})
require('dotenv').config()

app.use(session({
    secret:'ravi',
    resave:false,
    saveUninitialized:false
}))
app.use(authRouter)
app.use('/users',userRouter)
app.use('/admin',adminRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(process.env.PORT,()=>{console.log('server is running on port '+process.env.PORT)})