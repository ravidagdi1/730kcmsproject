function sub(req,res,next){
if(req.session.sub=='sub'){
    next()
}else{
    res.send("you don't have subscription to use this service")
}
}


module.exports=sub