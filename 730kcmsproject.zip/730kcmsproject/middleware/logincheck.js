function logincheck(req,res,next){
if(req.session.Auth){
    next()
}else{
    res.redirect('/')
}
}



module.exports=logincheck