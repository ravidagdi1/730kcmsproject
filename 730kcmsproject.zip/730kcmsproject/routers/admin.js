const router=require('express').Router()
const authc=require('../controllers/authcontroller')
const blogc=require('../controllers/blogcontroller')





module.exports=router