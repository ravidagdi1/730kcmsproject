const router=require('express').Router()
const authc=require('../controllers/authcontroller')
const blogc=require('../controllers/blogcontroller')
const logincheck=require('../middleware/logincheck')




router.get('/',authc.login)
router.post('/',authc.logincheck)
router.get('/singup',authc.singup)
router.post('/singup',authc.createuser)
router.get('/verifylink/:id',authc.statusupdate)
router.get('/forgot',authc.emailform)
router.post('/forgot',authc.forgotlinksend)
router.get('/forgotnewpass/:id',authc.forgotnewform)
router.post('/forgotnewpass/:id',authc.forgotpasswordupdate)
router.get('/logout',(req,res)=>{
    req.session.destroy()
    res.redirect('/')
})

router.get('/changepassword',authc.changepasswordform)
router.post('/changepassword',authc.changepassword)
router.get('/myprofile/:mess',logincheck,authc.profileform)
router.post('/myprofile/:id',authc.profileupdate)



module.exports=router