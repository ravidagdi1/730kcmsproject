const router=require('express').Router()
const authc=require('../controllers/authcontroller')
const logincheck=require('../middleware/logincheck')
const blogc=require('../controllers/blogcontroller')
const upload=require('../middleware/multer')
const subcheck=require('../middleware/subcheck')



router.get('/allblogs',logincheck,blogc.allblog)
router.get('/myblog/:mess',logincheck,blogc.myblog)
router.get('/addblog',logincheck,blogc.addform)
router.post('/addblog',upload.single('img'),blogc.addblog)






module.exports=router



